package com.app.market;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.annotation.Rollback;

import com.app.market.exception.CompanyAlreadyExistsException;
import com.app.market.model.Company;
import com.app.market.repository.CompanyRepository;
import com.app.market.service.CompanyServiceImpl;
import static org.mockito.Mockito.*;

import java.util.Optional;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CompanyServiceTest {

	private Company company;
	private List<Company> companyList;

	@Mock
	CompanyRepository companyRepository;
	@InjectMocks
	CompanyServiceImpl companyService;

	@BeforeEach
	public void setUp() {

		MockitoAnnotations.initMocks(this);
		companyList = new ArrayList<Company>();
		company = new Company("CC", "Coco", "CEO", 20, "wwww.coco.com", "BSE");
		companyList.add(company);

	}

	@AfterEach
	public void tearDown() throws Exception {
		company = null;
	}

	@Test
	@Rollback(true)
	public void tesAddCompanyDetailsSuccess() throws CompanyAlreadyExistsException {

		when(companyRepository.save(any())).thenReturn(company);

		assertEquals(company, companyService.addCompanyDetails(company));

		verify(companyRepository, times(1)).save(any());

	}

	@Test
	@Rollback(true)
	public void testGetCompanyByCodeSuccess() {

		when(companyRepository.findById(any())).thenReturn(Optional.of(company));

		assertEquals(company, companyService.getCompanyByCode(company.getCompanyCode()));

	}

	@Test
	@Rollback(true)
	public void testlistAllCompaniesSuccess() {

		when(companyRepository.findAll()).thenReturn(companyList);

		assertEquals(companyList, companyService.listAllCompanies());

		verify(companyRepository, times(1)).findAll();

	}
}
