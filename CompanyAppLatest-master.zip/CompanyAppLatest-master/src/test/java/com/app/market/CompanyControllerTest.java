package com.app.market;

import static org.mockito.Mockito.when;

import static org.mockito.ArgumentMatchers.any;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import com.app.market.controller.v1.CompanyController;
import com.app.market.model.Company;
import com.app.market.service.CompanyService;
import com.fasterxml.jackson.databind.ObjectMapper;


public class CompanyControllerTest {
	    private MockMvc mockMvc;
	    private Company company;
	    private List<Company> companyList;

	    @Mock
	    CompanyService companyService;
	    @InjectMocks
	    CompanyController companyController;

	    @BeforeEach
	    public void setUp() {

	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders.standaloneSetup(companyController).build();
	        companyList = new ArrayList<Company>();
	        company = new Company("CC", "Coco", "CEO", 20, "wwww.coco.com", "BSE");
	        companyList.add(company);

	    }

	    @Test
	    public void addCompanySuccess() throws Exception {

	        when(companyService.addCompanyDetails(any())).thenReturn(company);
	        mockMvc.perform(post("/api/v1.0/market/company/register").contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(company)))
	                .andExpect(status().isCreated()).andDo(MockMvcResultHandlers.print());

	    }
	    
	    @Test
	    public void getAllCompaniesSuccess() throws Exception {

	        when(companyService.listAllCompanies()).thenReturn(companyList);
	        mockMvc.perform(get("/api/v1.0/market/company/getAll").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
	                .andDo(MockMvcResultHandlers.print());
	    }
	    
	    @Test
	    public void getCompanyByCodeTest() throws Exception {

	        when(companyService.getCompanyByCode("CC")).thenReturn(company);
	        mockMvc.perform(get("/api/v1.0/market/company/info/CC").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
	                .andDo(MockMvcResultHandlers.print());
	    }

}
