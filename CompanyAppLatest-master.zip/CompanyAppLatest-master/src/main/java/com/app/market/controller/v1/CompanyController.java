package com.app.market.controller.v1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.market.exception.CompanyAlreadyExistsException;
import com.app.market.model.Company;
import com.app.market.service.CompanyService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1.0/market/company")
public class CompanyController {

	private CompanyService companyService;

    @Autowired
    public CompanyController(CompanyService companyService) {
        this.companyService = companyService;
    }
    
   // @Autowired
    //KafkaTemplate<String, String> template;
    

	@PostMapping("/register")
	public ResponseEntity<Company> addCompany(@RequestBody Company company) throws CompanyAlreadyExistsException {
		return new ResponseEntity<>(companyService.addCompanyDetails(company), HttpStatus.CREATED);
	}

	@GetMapping("getAll")
	public ResponseEntity<List<Company>> listAllCompanies() {
		//template.send("devglan-test","Hello");
		return new ResponseEntity<>(companyService.listAllCompanies(), HttpStatus.OK);
	}

	@GetMapping("/info/{companyCode}")
	public ResponseEntity<Company> getByCode(@PathVariable String companyCode)  {
		return new ResponseEntity<>(companyService.getCompanyByCode(companyCode), HttpStatus.OK);
	}

	@DeleteMapping("/delete/{companyCode}")
	public ResponseEntity<Company> deleteCompany(@PathVariable String companyCode) {
		companyService.deleteCompany(companyCode);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
