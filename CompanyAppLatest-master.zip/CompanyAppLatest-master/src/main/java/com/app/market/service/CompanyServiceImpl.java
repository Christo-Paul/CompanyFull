package com.app.market.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.market.exception.CompanyAlreadyExistsException;
import com.app.market.model.Company;
import com.app.market.repository.CompanyRepository;

@Service
public class CompanyServiceImpl implements CompanyService {

	private CompanyRepository companyRepository;

	@Autowired
	public CompanyServiceImpl(CompanyRepository companyRepository) {
		this.companyRepository = companyRepository;
	}

	@Override
	public Company addCompanyDetails(Company company) throws CompanyAlreadyExistsException {
		if (companyRepository.findById(company.getCompanyCode()).isPresent()) {
            System.out.println("Company already exists");
           throw new CompanyAlreadyExistsException("Company already exists");
        }
        return companyRepository.save(company);
	}

	@Override
	public List<Company> listAllCompanies() {
		 return companyRepository.findAll();
	}

	@Override
	public Company getCompanyByCode(String companyCode) {
		 if (!companyRepository.findById(companyCode).isPresent()) {
			 System.out.println("Company doesnot exists");
			 return new Company();
	        }
	        return companyRepository.findById(companyCode).get();
	}

	@Override
	public void deleteCompany(String companyCode) {
		if (companyRepository.findById(companyCode).isPresent()) {
			 System.out.println("Company doesnot exists");
        }
        companyRepository.deleteById(companyCode);
	}

}
