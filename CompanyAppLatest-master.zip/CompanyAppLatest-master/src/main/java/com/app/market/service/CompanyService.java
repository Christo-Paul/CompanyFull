package com.app.market.service;

import java.util.List;

import com.app.market.exception.CompanyAlreadyExistsException;
import com.app.market.model.Company;

public interface CompanyService {

	Company addCompanyDetails(Company company) throws CompanyAlreadyExistsException;

	List<Company> listAllCompanies();

	Company getCompanyByCode(String companyCode);

	void deleteCompany(String companyCode);

}
