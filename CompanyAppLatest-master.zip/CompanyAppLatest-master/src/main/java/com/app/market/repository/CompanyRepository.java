package com.app.market.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.market.model.Company;

public interface CompanyRepository extends JpaRepository<Company, String> {

}
