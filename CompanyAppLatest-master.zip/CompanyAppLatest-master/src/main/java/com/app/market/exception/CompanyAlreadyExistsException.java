package com.app.market.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.CONFLICT, reason = "Specified Program already exists")
public class CompanyAlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8876542810948343359L;
	
	private String message;

	public CompanyAlreadyExistsException(String message) {
		super();
		this.message = message;
	}

}

