import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardServiceService implements CanActivate{

  constructor(public router: Router) {
   }
   canActivate(){
    if (!!!sessionStorage.getItem("TOKEN")) {
      this.router.navigate(['login']);
      return false;
    }
    return true;
   }
}
