import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Company } from '../model/company.model';
import { environment } from 'src/environments/environment';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json',
  'Access-Control-Allow-Origin':'*' },
  )
};
@Injectable({
  providedIn: 'root'
})
export class CompanyService {
 onDelete(code: string) {
   
   return this.http.delete(environment.DEL_COMPANY_API+'/'+code+'/');
 }

 // companies: Company[]=[];
 constructor(private http: HttpClient) { }

 getAll(): Observable<any> {
   return this.http.get(environment.LIST_COMPANY_API);
 }

 onAdd(company:Company){

  return this.http.post(environment.ADD_COMPANY_API,company,httpOptions);

 }

 onFetch(code: string) {
   
  return this.http.get(environment.GET_COMPANY_API+'/'+code+'/');
}

}
