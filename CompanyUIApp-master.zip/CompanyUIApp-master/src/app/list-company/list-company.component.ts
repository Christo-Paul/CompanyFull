import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Company } from '../model/company.model';
import { CompanyStock } from '../model/companyStock.model';
import { CompanyService } from '../services/company.service';
import { StockServiceService } from '../services/stock-service.service';

@Component({
  selector: 'app-list-company',
  templateUrl: './list-company.component.html',
  styleUrls: ['./list-company.component.css']
})
export class ListCompanyComponent implements OnInit {
  [x: string]: any;
  content : Company[];
  response!: any;
  fetchResponse!: Company;
  id: any;
  companyDisplay= false;
  noResult=false;
  stockListResponse: any;
  stockPrice: number[];
  stockPriceFetch: number[];
  technologies :string[] ;
  j: number=0;
  stkPrice : number[];
  searchStockPrice: number;
  companyStockmap = new Map();
 
    

  constructor(private route: ActivatedRoute,private router: Router,private companyService: CompanyService, private stockService:StockServiceService) { 
   this.content=[];
   this.stockListResponse=[];
   this.stockPrice=[];
   this.stockPriceFetch=[];
   this.technologies=[];
   this.j=0;
   this.stkPrice=[];
   this.searchStockPrice=0;
  }

   ngOnInit() {
    

    this.route.queryParams
    .subscribe(params => {
      console.log("v",params); // { order: "popular" }
      this.noResult=false;
      this.id=params.myinput;
         })
    console.log("vvv",this.id);
    if(!(this.id === undefined))
    {
      console.log("searchFlow");
      this.onFetchfromSearch(this.id);
    }


    console.log("in listcomponent");
    // fetch all the programs and assign to content
     this.companyService.getAll().subscribe(
        data => {
        this.content = data;
        // console.log("data" , data);

        for(let i=0; i< this.content.length; i++){
        console.log(this.content[i].companyCode,"i value",i); //use i instead of 0
        this.fetchStockPrice(String(this.content[i].companyCode));
        setTimeout(function() {
          //your code to be executed after 1 second
        }, 4000);
      
        console.log("company",this.content[i].companyCode,"price",this.stockPrice[i]);
        console.log("company",this.content[i].companyCode,this.stockPriceFetch[i]);
      // this.companyStockmap.set(this.content[i].companyCode,this.stockPriceFetch[i]);
      }
        
      },
      err => {
        this.content = JSON.parse(err.error).message;
      }
    );
   // this.companyStockmap.set("CC",this.stockPriceFetch[1]);
     
  }

  onDelete(code: string){
    this.companyService.onDelete(code).subscribe(
      data => {
        this.response = data;
        // console.log("data" , data);
      },
      err => {
        this.response = JSON.parse(err.error).message;
      }
    );

    this.stockService.onDeleteStocks(code).subscribe(
      data => {
        this.response = data;
      },
      err => {
        this.response = JSON.parse(err.error).message;
      }
    );



    window.location.reload();
  }

  onFetch(){
    let input : string | undefined;
     input=(<HTMLInputElement>document.getElementById("myinput")).value;
    
    console.log("value", input);
    this.companyService.onFetch(input).subscribe(
      data => {
        this.fetchResponse = data;
         console.log("data serch not used" , data);
         this.companyDisplay=true;
      },
      err => {
        this.fetchResponse = JSON.parse(err.error).message;
      }
    );
    this.companyDisplay=true;
  }

  onFetchfromSearch(input: string){
    
   // var input=(<HTMLInputElement>document.getElementById("myinput")).value;
  
    console.log("value rrr", input);
    this.companyService.onFetch(input).subscribe(
      data => {
        this.fetchResponse = data;
         console.log("data search" , data);
         if(this.fetchResponse.companyCode===null){
          this.noResult=true;
         }else{
         this.companyDisplay=true;
         }

      },
      err => {
       // this.fetchResponse = JSON.parse(err.error).message;
        this.noResult=true;
        console.log("error rep");
      }
    );
    this.fetchCompanyStockPrice(input);
  }



   fetchStockPrice(chosenCompany:string|undefined ): number{
    
    console.log("data chhosennn" , chosenCompany);
    this.stockService.onFetchStocks(String(chosenCompany)).subscribe(
      
      data => {
        this.stockListResponse = data ;
         console.log("data1" , data);

         if(this.stockListResponse.length===0)
         {
          this.stockPriceFetch[this.j]=0;
          console.log("No Stock for the company","j",this.j);
          this.j=this.j+1;
        
         }else {
       //  for(let i=0; i< this.stockListResponse.length; i++){
      //    console.log(this.stockListResponse[i].price); //use i instead of 0
     // }
      console.log(new Date(Math.max.apply(null, this.stockListResponse.map(function(e: { date: string | number | Date; }) {
        return new Date(e.date);
      }))));
      let latestStockdate = new Date((Math.max.apply(null, this.stockListResponse.map(function(e: { date: string | number | Date; }) {
        return new Date(e.date);
      }))));// let d2 = new Date(date2);

  // Check if the dates are equal
  for(let k=0; k< this.stockListResponse.length; k++){
    console.log(this.stockListResponse[k].price); //use i instead of 0
    let same = latestStockdate.getTime() === new Date(this.stockListResponse[k].date).getTime();
    if (same){
      if(chosenCompany===this.stockListResponse[k].companyCode){
      this.stockPriceFetch[this.j]=Number(this.stockListResponse[k].price);
      this.companyStockmap.set(chosenCompany,Number(this.stockListResponse[k].price));
      console.log("match" ,this.stockListResponse[k].price," - ","j",this.j);
      console.log("matchPricefetch", this.stockPriceFetch[this.j],this.j,"chose comp",chosenCompany);
      this.j=this.j+1;
          
      }
     // return this.stockListResponse[i].price;
    } 
}
  
} 
      },
      err => {
        this.stockListResponse = JSON.parse(err.error).message;
        
      }
    );
   // window.location.reload();
  
  console.log("jj finished",this.j);
  this.technologies = ['HTML', 'CSS', 'javaScript', 'jQuery', 'bootstrap', 'Angular'];
return 255;
  }
  

  addPrice(pos: number,ccode:string,companyName:string){
    console.log(this.stkPrice[pos]+"entered value"+this.enteredPrice);

    let stock: CompanyStock={
      id : Math.random().toString(36).substr(2, 9),
      companyCode : ccode,
      name : companyName+"_Shares",
      price :this.stkPrice[pos],
      date: undefined
    }
    console.log(stock);

    this.stockService.onAddStocks(stock).subscribe(
      data => {
       // this.companyAdded =true;
       // this.message = 'Company added';
        
       // this.router.navigateByUrl('');
       console.log("added");
      },
      err=>{
       // this.companyAdded =true;
         // this.message = err.error.message;    
        // this.message = 'Exception Occurrred !! CompanyCode already exists'; 
          console.log(" exception in adding");        
      }
    );
        
    window.location.reload();
  }

  onsee(){
    console.log("hello");
  }

  


  fetchCompanyStockPrice(chosenCompany:string|undefined ){
    
    this.stockService.onFetchStocks(String(chosenCompany)).subscribe(
      
      data => {
        this.stockListResponse = data ;
         console.log("data1" , data);

         if(this.stockListResponse.length===0)
         {
         
          this.searchStockPrice=0;
          console.log("No Stock for the company");
          
        
         }else {
       
      console.log(new Date(Math.max.apply(null, this.stockListResponse.map(function(e: { date: string | number | Date; }) {
        return new Date(e.date);
      }))));
      let latestStockdate = new Date((Math.max.apply(null, this.stockListResponse.map(function(e: { date: string | number | Date; }) {
        return new Date(e.date);
      }))));// let d2 = new Date(date2);

  // Check if the dates are equal
  for(let k=0; k< this.stockListResponse.length; k++){
    console.log(this.stockListResponse[k].price); //use i instead of 0
    let same = latestStockdate.getTime() === new Date(this.stockListResponse[k].date).getTime();
    if (same){
      if(chosenCompany===this.stockListResponse[k].companyCode){
         this.searchStockPrice=this.stockListResponse[k].price;
      }
    
    } 
}
  
}
      },
      err => {
        this.stockListResponse = JSON.parse(err.error).message;
        
      }
    );
   
    }

}
