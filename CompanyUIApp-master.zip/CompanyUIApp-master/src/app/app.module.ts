import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddCompanyComponent } from './add-company/add-company.component';
import { ListCompanyComponent } from './list-company/list-company.component';
import { FormsModule } from '@angular/forms';
import { ViewStockComponent } from './view-stock/view-stock.component';
import { DatePipe } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import Amplify from 'aws-amplify';
Amplify.configure({
  Auth:{
    mandatorySignIn:true,
    region: 'us-east-2',
    userPoolId: 'us-east-2_9RcCezbgz',
    userPoolWebClientId: '2tt70amh529of2un4qgdt0lo6b',
    authenticationFlowType:'USER_PASSWORD_AUTH'
  }

});
@NgModule({
  declarations: [
    AppComponent,
    AddCompanyComponent,
    ListCompanyComponent,
    ViewStockComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
