export interface CompanyStock{

    id ?: string;
    companyCode ?: string;
    name ?: string;
    price ?:number;
    date?: Date;
}