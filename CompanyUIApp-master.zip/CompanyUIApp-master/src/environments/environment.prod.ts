export const environment = {
  production: true,

  
  DEL_COMPANY_API : 'http://localhost:8100/company-service/api/v1.0/market/company/delete',
  LIST_COMPANY_API : 'http://localhost:8100/company-service/api/v1.0/market/company/getAll',
  ADD_COMPANY_API :  'http://localhost:8100/company-service/api/v1.0/market/company/register',
  GET_COMPANY_API : 'http://localhost:8100/company-service/api/v1.0/market/company/info',

  DEL_STOCK_API: 'http://localhost:8100/stock-app/api/v1.0/market/stock/delete',
  ADD_STOCK_API: 'http://localhost:8100/stock-app/api/v1.0/market/stock/add/',
  GET_STOCK_API: 'http://localhost:8100/stock-app/api/v1.0/market/stock/get'
};
