package com.app.market.stock.model;

import java.util.Date;

import org.springframework.data.annotation.Id;


public class Stock {
	
	private String name;
	private float price;
	private Date date;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Stock [name=" + name + ", price=" + price + ", date=" + date + "]";
	}
	public Stock(String name, float price, Date date) {
		super();
		this.name = name;
		this.price = price;
		this.date = date;
	}
	public Stock() {
		super();
	}
	
}
