package com.app.market.stock.service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.market.stock.model.CompanyStock;
import com.app.market.stock.model.Stock;
import com.app.market.stock.repository.StockRepository;

@Service
public class StockServiceImpl implements StockService  {
	
	private StockRepository stockRepository;

	@Autowired
	public StockServiceImpl(StockRepository stockRepository) {
		this.stockRepository = stockRepository;
	}

	
	public CompanyStock addNewStock(CompanyStock companyStock) {
		
        return stockRepository.save(companyStock);
	}
	
	@Override
	public List<CompanyStock> getStock(String companyCode, Date startDate, Date endDate) {

		endDate = DateUtils.addHours(endDate, 24);
		LocalDate localEndDate = endDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		return stockRepository.findStockByDate(companyCode, startDate, localEndDate);
	}
	
	@Override
	public List<CompanyStock> getCompanyStockbyCode(String companyCode) {
		 
	        return stockRepository.findStockByCode(companyCode);
	}

	@Override
	public Long deleteCompanyStockByCompanyCode(String code) {
		return stockRepository.deleteCompanyStockByCompanyCode(code);
	}
}
