package com.app.market.stock.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "companyStock")
public class CompanyStock extends Stock {

	@Id
	private String id;
	private String companyCode;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public CompanyStock(String name, float price, Date date, String id, String companyCode) {
		super(name, price, date);
		this.id = id;
		this.companyCode = companyCode;
	}
	@Override
	public String toString() {
		return "CompanyStock [id=" + id + ", companyCode=" + companyCode + "]";
	}
	public CompanyStock(String name, float price, Date date) {
		super(name, price, date);
	}
	 
	public CompanyStock() {
		super();
	}
	 
	
	
}
