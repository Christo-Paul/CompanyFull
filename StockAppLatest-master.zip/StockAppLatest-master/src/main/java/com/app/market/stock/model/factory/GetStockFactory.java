package com.app.market.stock.model.factory;

import com.app.market.stock.model.CompanyStock;
import com.app.market.stock.model.Stock;

public class GetStockFactory {

	public Stock getStock(String stockType) {
		if (stockType == null) {
			return null;
		}
		if (stockType.equalsIgnoreCase("COMPANYSTOCK")) {
			return new CompanyStock();
		}
		return null;
	}
}
