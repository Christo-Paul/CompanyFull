package com.app.market.stock.repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.app.market.stock.model.CompanyStock;

public interface StockRepository extends MongoRepository<CompanyStock, String> {

	
	@Query("{'companyCode' : ?0 , 'date' : { $gte: ?1, $lte: ?2 }}")
	List<CompanyStock> findStockByDate(String companyCode, Date startDate, LocalDate endDate);

	@Query("{'companyCode' : ?0 }")
	List<CompanyStock> findStockByCode(String companyCode);
	
    Long deleteCompanyStockByCompanyCode(String code);

}
